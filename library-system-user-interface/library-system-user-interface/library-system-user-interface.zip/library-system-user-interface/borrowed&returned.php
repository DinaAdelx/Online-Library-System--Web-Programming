<!DOCTYPE html>
<html>
<?php include 'head.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  

  <!-- Main Sidebar Container -->
  <?php include 'sidebar&navbar.html' ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
                    <h1>Borrowed and Returned</h1>
        </div>
          
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
          <div class="card-header">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add-borrow_book">
                  Add Borrow Book
            </button>
              <?php include 'modals.php'; ?>
          </div>
        <div class="card-body">
          <table id="example1" class="table table-bordered table-striped">
                <thead style="font-size:13px">
                <tr>
                  <th>ID</th>
                  <th>Book ID/Name</th>
                  <th>Borrower ID</th>
                  <th>Borrower Name</th>
                  <th>Date Borrowed</th>
                  <th>Due Date</th>
                  <th>No. of Copies</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                    <td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#return_book">Returned</button>
                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-borrow_book">Edit</button></td>
                </tr>
                </tbody>
              </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

        <!-- Default box -->
      <div class="card">
          <div class="card-header">
              <h3>Returned Books</h3>
          </div>
        <div class="card-body">
          <table id="example4" class="table table-bordered table-striped">
                <thead style="font-size:13px">
                <tr>
                  <th>ID</th>
                  <th>Book Name</th>
                  <th>Borrower Name</th>
                  <th>Date Borrowed</th>
                  <th>Due Date</th>
                  <th>No. of Copies</th>
                  <th>Book Status</th>
                  <th>Processed By</th>
                  <th>Date Returned</th>
                  <th>Received by</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                  <td>Trident</td>
                </tr>
                </tbody>
              </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include 'footer&scripts.php'; ?>
    </div>
</body>
</html>
